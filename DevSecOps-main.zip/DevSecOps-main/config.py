SNYK_API_TOKEN = 'your-snyk-api-token'
AZURE_WEBHOOK_SECRET = 'your-azure-webhook-secret'
